package dit;

public class C2 extends B {

}
