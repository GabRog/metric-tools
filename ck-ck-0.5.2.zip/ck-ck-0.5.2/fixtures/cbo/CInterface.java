package cbo;

public interface CInterface {

}
