package cbo;

public class C extends B {

	public void method(){}
}
