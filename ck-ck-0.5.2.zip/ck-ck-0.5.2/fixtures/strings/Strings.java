package strings;

class Strings {
	
	public void m1() {
		String a1 = "Mau";

		String b1 = "An";
	}

	public void m2() {
		System.out.println("B" + "C");
	}

	public void m3() {
		
	}
}