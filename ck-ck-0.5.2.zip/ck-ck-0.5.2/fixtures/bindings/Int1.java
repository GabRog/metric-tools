package bind;

interface Int1 {
	void x();
}