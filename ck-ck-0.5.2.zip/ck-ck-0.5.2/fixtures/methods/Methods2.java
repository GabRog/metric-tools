package methods;

public abstract class Methods2 {

	private abstract int a() {}
	private String b() {}

	protected abstract boolean c(){}

}