import pac.B;
import pac.Missing;
import pacmissing.Missing2;

class A {
	void m1(B p1, pac.B p2, Missing p3, pac.Missing p4, Missing2 p5, pacmissing.Missing2 p6) {
	}
}
