package pac;

public class B {
}
