package nestedblocks;

enum SimpleEnum {
	A,
	B,
	C,
	D
}